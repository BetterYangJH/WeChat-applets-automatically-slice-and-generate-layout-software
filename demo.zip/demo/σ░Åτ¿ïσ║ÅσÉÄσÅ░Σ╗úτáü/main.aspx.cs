﻿using System;using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Xml;
using System.Text;

public partial class main : System.Web.UI.Page
{
    string sql = "";
   
    public db cls_db = new db();

    public DataTable dt;

    public string action = "";    
    public string xml = "";
    public string pic_url="";
    public string nopic="nopic.gif";
    public string uid="";
    public string id="";
    public string imei="";
    public string bundle = "";

    int RecordCount=0;
    int Pagesize=0;
    int PageCount=0;

    



    protected void Page_Load(object sender, EventArgs e)
    {
		//获取基础参数
		action = Request["action"];//得到action
		uid =Request["uid"];//得到uid
		id = Request["id"];//得到id

		//定义界面来的变量




		xml+="{";

		if(action=="init"){


			
		}



		xml+=data_refresh();

		xml+="\"page_end\":\"\"}";

		Response.Write(xml);
    }





   public string data_refresh()
    {
	   string xml="";


       return xml;
    }   
}
