var app = getApp();Page({  
  /**
   * 页面的初始数据
   */
  data: {  
     
    id:'',//方便存在本地的locakStorage  
    response:'' //存取返回数据  
  }, 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.checkLogin();

    if (options.id != null && options.id !=""){
      this.setData({
        id: options.id
      })
    }   
    //执行初始化
    this.dataRefresh("init");
  },
  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
	//执行初始化
	this.dataRefresh("init");
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * ---------------------------------------
   */

  /**
* Img处理函数
*/
main_2_click:function(){

},

/**
* text处理函数
*/
main_3_click:function(e){

},

/**
* Img处理函数
*/
main_10_click:function(){

},

/**
* text处理函数
*/
main_11_click:function(e){

   wx.navigateTo({
   url:'/pages/tt/tt'
  })
},

/**
* Img处理函数
*/
main_12_click:function(){

},

/**
* Img处理函数
*/
main_13_click:function(){

},

/**
* Img处理函数
*/
main_14_click:function(){

},

/**
* Img处理函数
*/
main_15_click:function(){

},

/**
* Img处理函数
*/
main_16_click:function(){

},

/**
* text处理函数
*/
main_17_click:function(e){

},

/**
* text处理函数
*/
main_18_click:function(e){

},

/**
* text处理函数
*/
main_19_click:function(e){

},

/**
* text处理函数
*/
main_20_click:function(e){

},

/**
* Img处理函数
*/
main_21_click:function(){

},

/**
* Img处理函数
*/
main_22_click:function(){

},

/**
* Img处理函数
*/
main_23_click:function(){

},

/**
* Img处理函数
*/
main_24_click:function(){

},


 
  /**
   * ---------------------------------------
   */

  //刷新数据
  dataRefresh:function(_action) {
    //提交到服务器
    var that = this
    wx.request({
      url: 'https://test.ymznkf.com/wx_server//main.aspx',
      data: {
        action: _action,
        uid: app.data.uid,
        //定义变量---start
	
        //定义变量---end
        id: that.data.id
      },
      method: 'GET',
      success: function (res) {
        console.log(res.data);
        var tmp = res.data;

        if(_action=="init"){
		that.setData({

			response: res
		})
	}

	that.setData({
		
		response: res
        })

	 if (tmp.message != null && tmp.message != "") {
          wx.showToast({
            title: tmp.message,
            icon: 'none',
            duration: 2000
          })
        }
      },
      fail: function (res) {
        console.log(res.data);
        console.log('is failed')
      }
    })
  },

   /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})  

